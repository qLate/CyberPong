#if !defined(Debug_H)
#define Debug_H

    
#include "project.h"
#include "main_data.h"
#include <stdio.h>

void Print(char text[]);
void Println(char text[]);

void PrintMotorSpeeds();


#endif
/* [] END OF FILE */

