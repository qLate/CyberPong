#if !defined(Bluetooth_H)
#define Bluetooth_H


#include "project.h"
#include "main_data.h"
#include "debug.h"
#include "motorController.h"
  
void AIOS_Handler(uint32 eventCode, void *eventParams);
void AIOS_Callback(uint32 eventCode, void *eventParam);


#endif
/* [] END OF FILE */
